function calculateSquareArea() {
  document.getElementById('areaOfSquare').innerHTML = Number(document.getElementById('sideOfSquare').value) ** 2 ;
}

function calculateRectangleArea() {
  document.getElementById('areaOfRectangle').innerHTML = Number(document.getElementById('sideOfRectangle1').value) * Number(document.getElementById('sideOfRectangle2').value)  ;
 
}