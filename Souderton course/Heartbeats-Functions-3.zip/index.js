function calculate30Sec(){
  document.getElementById('result1').innerHTML = Number(document.getElementById('pulse').value) 
}

function calculate1Min(){
  document.getElementById('result2').innerHTML = Number(document.getElementById('pulse').value) * 2
}

function calculate1Hour(){
  document.getElementById('result3').innerHTML = Number(document.getElementById('pulse').value) * 2 * 60
}

function calculate1Day(){
document.getElementById('result4').innerHTML = Number(document.getElementById('pulse').value) * 2 * 60 * 24
}

function calculate1Year(){
document.getElementById('result5').innerHTML = Number(document.getElementById('pulse').value) * 2 * 60 * 24 * 365
}
}