
function iceCream(){
  let  strFirsname = document.getElementById("firstName").value
  let  strLastname = document.getElementById("lastName").value
  let strHoursworked = document.getElementById("workHours").value
    let  numSundaes = Number(document.getElementById("sundaes").value)
 
   let  numCones = document.getElementById("cones1").value
  let  numShakes = document.getElementById("shakes1").value
  let strEmployees = document.getElementById("employees1").value
  
  let strNotes = document.getElementById("noteNumber").value
  let numQuartsIceCream = ((numCones * 8 ) + (numCones * 6) + (numShakes * 10)) /32
  
  let numQuartsSauce = ((numCones * 2) + (numShakes * 3)) / 32
  let numPoundsofNuts = ((numCones * 10)) / 16
  
 
  let strIcecream = "Name: " + strFirsname + " " + strLastname 
  + "<br><br>Hours Worked: " + strHoursworked + " " + "<br><br>Sundaes: " + numPoundsofNuts + " " + "<br><br>Quarts of sauce: " + numQuartsSauce + " " + "<br><br>Quarts of ice cream: " + numQuartsIceCream + " " + "<br><br>Number of Employees: " + strEmployees + " " + " <br><br>Notes: " + strNotes + " "; 

document.getElementById("finalReport").innerHTML = strIcecream

}
